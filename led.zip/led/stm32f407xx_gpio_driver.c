/*
 * stm32f407xx_gpio_driver.c
 *
 *  Created on: Sep 16, 2021
 *      Author: 99005839
 */

#include "stm32f407xx_gpio_driver.h"

/*
 * brief: Initialize pins
 * @param1 	 : pointer to structure to select port
 * @retValue :None
 */
void GPIO_Init(GPIO_Handle_t *pGPIOHandle)
{
	uint32_t temp;

	//1. mode
	temp = ((pGPIOHandle->GPIO_PinConfig.GPIO_PinMode)<<(2*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
	pGPIOHandle->pGPIOx->MODER &= (~((03)<<2*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
	pGPIOHandle->pGPIOx->MODER |= temp;
	temp = 0;

	//2. speed
	temp = ((pGPIOHandle->GPIO_PinConfig.GPIO_PinSpeed)<<(2*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
	pGPIOHandle->pGPIOx->OSPEEDR &= (~((03)<<2*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
	pGPIOHandle->pGPIOx->OSPEEDR |= temp;
		temp = 0;

	// 3. pull up or down
	temp = ((pGPIOHandle->GPIO_PinConfig.GPIO_PinPullControl)<<(2*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
	pGPIOHandle->pGPIOx->PUPDR &= (~((03)<<2*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
	pGPIOHandle->pGPIOx->PUPDR |= temp;
		temp = 0;

	// 4. alternate function mode
	if(pGPIOHandle->GPIO_PinConfig.GPIO_PinMode == GPIO_MODE_ALT_FN)
	{
		uint8_t temp1 , temp2;
		temp1 = pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber/8;
		temp2 = pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber%8;
		pGPIOHandle->pGPIOx->AFR[temp1] &= ~(0xf<<(4*temp2));
		pGPIOHandle->pGPIOx->AFR[temp1] |= (pGPIOHandle->GPIO_PinConfig.GPIO_PinSpeed<<(4*temp2));
	}

	// 5. output type
	temp = ((pGPIOHandle->GPIO_PinConfig.GPIO_PinOPType)<<(2*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
	pGPIOHandle->pGPIOx->OTYPER &= (~(1<<1*pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber));
	pGPIOHandle->pGPIOx->OTYPER |= temp;
}


/*
 * brief: De-Initialize pins
* @param1 	 : pointer to structure to select port
* @retValue : None
*/
void GPIO_DeInit(GPIO_RegDef_t *pGPIOx)
{
	if(pGPIOx == GPIOA)
	{
		GPIOA_REG_RESET();
	}
	else if(pGPIOx == GPIOB)
	{
		GPIOB_REG_RESET();
	}
	else if(pGPIOx == GPIOC)
		{
			GPIOC_REG_RESET();
		}
	else if(pGPIOx == GPIOD)
		{
			GPIOD_REG_RESET();
		}
	else if(pGPIOx == GPIOE)
		{
			GPIOE_REG_RESET();
		}
	else if(pGPIOx == GPIOF)
		{
			GPIOF_REG_RESET();
		}
	else if(pGPIOx == GPIOG)
		{
			GPIOG_REG_RESET();
		}
	else if(pGPIOx == GPIOH)
		{
			GPIOH_REG_RESET();
		}
	else if(pGPIOx == GPIOI)
		{
			GPIOI_REG_RESET();
		}
}


/*
 * brief: Peripheral clock control
 * @param1 	 : pointer to structure to select port
 * @param2	 : clock enabled or disabled
 * @retValue : None
 */
void GPIO_PeriClockControl(GPIO_RegDef_t *pGPIOx, uint8_t ENorDi)
{
	if(ENorDi==ENABLE)
	{
		if(pGPIOx == GPIOA)
			GPIOA_PCLK_EN();
		else if(pGPIOx == GPIOB)
			GPIOB_PCLK_EN();
		else if(pGPIOx == GPIOC)
			GPIOC_PCLK_EN();
		else if(pGPIOx == GPIOD)
			GPIOD_PCLK_EN();
		else if(pGPIOx == GPIOE)
			GPIOE_PCLK_EN();
		else if(pGPIOx == GPIOF)
			GPIOF_PCLK_EN();
		else if(pGPIOx == GPIOG)
			GPIOG_PCLK_EN();
		else if(pGPIOx == GPIOH)
			GPIOH_PCLK_EN();
		else if(pGPIOx == GPIOI)
			GPIOI_PCLK_EN();
	}
	else if(ENorDi == DISABLE)
	{
		if(pGPIOx == GPIOA)
			GPIOA_PCLK_DI();
		else if(pGPIOx == GPIOB)
			GPIOB_PCLK_DI();
		else if(pGPIOx == GPIOC)
			GPIOC_PCLK_DI();
		else if(pGPIOx == GPIOD)
			GPIOD_PCLK_DI();
		else if(pGPIOx == GPIOE)
			GPIOE_PCLK_DI();
		else if(pGPIOx == GPIOF)
			GPIOF_PCLK_DI();
		else if(pGPIOx == GPIOG)
			GPIOG_PCLK_DI();
		else if(pGPIOx == GPIOH)
			GPIOH_PCLK_DI();
		else if(pGPIOx == GPIOI)
			GPIOI_PCLK_DI();
	}
}

/*
 * brief: Read input from pin
 * @param1 	 :pointer to structure to select port
 * @param2	 : variable for pin number
 * @retValue : Value read from pin specified by pin number
 */
uint8_t GPIO_ReadFromInputPin(GPIO_RegDef_t *pGPIOx, uint8_t PinNumber)
{
	uint8_t Value;
		Value = (uint8_t) ((pGPIOx->IDR >> PinNumber) & 00000001);
		return Value;
}


/*
 * brief: Read input from port
 * @param1 	 :pointer to structure to select port
 * @retValue : Value read from port
*/
uint32_t GPIO_ReadFromInputPort(GPIO_RegDef_t *pGPIOx)
{
	uint32_t Value;
	Value = pGPIOx->IDR;
	return Value;
}


/*
 * brief:Write output to pin
 * @param1 	 :pointer to structure to select port
 * @param2	 : variable for pin number
* @param3 	 : value to be written
 * @retValue : None
*/
void GPIO_WriteToOutputPin(GPIO_RegDef_t *pGPIOx, uint8_t PinNumber,uint8_t Value)
{
	if(Value == GPIO_PIN_SET)
	{
		pGPIOx->IDR |= (1<<PinNumber);
	}
	if(Value == GPIO_PIN_RESET)
	{
		pGPIOx->IDR &= ~(1<<PinNumber);
	}
}

/*
 * brief:Write output to port
 * @param1 	 :pointer to structure to select port
 * @param2	 : value to be written
 * @retValue : None
 */
void GPIO_WriteToOutputPort(GPIO_RegDef_t *pGPIOx,uint32_t Value)
{
	 pGPIOx->ODR = Value;
}


/*
 * brief: Toggle Pin output
 * @param1 	 :pointer to structure to select port
 * @param2	 :	variable for pin number
 * @retValue : None
 */
 void GPIO_ToggleOutputPin(GPIO_RegDef_t *pGPIOx, uint8_t PinNumber)
 {
	 pGPIOx->ODR ^= (1<<PinNumber);
 }

